package com.training;
public class integerArray {  
    public static void main(String[] args)
    {   
    	int A[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
        int sum = 0; 
        int min = A[0];
        for(int i =0; i<=17; i++){
            if(min>A[i]){
                min = A[i];
            }
            sum+=A[i];
        }
        int avg = sum/18;
        A[14] = sum;
        A[16] = min;
        A[15] = avg;
         
        for(int i = 0; i<A.length; i++){
            System.out.print(A[i]);
            System.out.print(" ");
        }
       
    }
 
}